package books;

import java.util.ArrayList;
import java.util.List;

import inventory.searchpackage.SearchInterface;

public class BookManager {
    private List<Book> books;

    public BookManager() {
        books = new ArrayList<>();
    }

    public void addBook(Book book) {
        for (Book b : books) {
            if (b.getBookId() != null && b.getBookId().equals(book.getBookId())) {
                System.out.println("Book with same Booking ID already exists!");
                return;
            }
        }
        books.add(book);
        System.out.println("Book added successfully!");
    }


    public void removeBook(Book book){
        if(books.contains(book)){
            books.remove(book);
        }
    }


    public List<Book> getBooks(){
        return books;
    }

    public List<Book> searchBy(SearchInterface searcher,  String value){
        return searcher.search(books, value);
    }
}
