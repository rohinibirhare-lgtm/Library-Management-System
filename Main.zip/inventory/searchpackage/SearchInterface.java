package inventory.searchpackage;

import java.util.List;

import books.Book;

public interface SearchInterface {
    List<Book> search(List<Book> books, String value);
}
