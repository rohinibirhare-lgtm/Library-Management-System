package users;

import java.util.ArrayList;
import java.util.List;

import books.Book;

public class PatronManager {
    private List<User> users;

    public PatronManager() {

        users = new ArrayList<>();

    }


    public void addUser(User user){
        for (User u : users) {
            if (u.getUserId() != null && u.getUserId().equals(user.getUserId())) {
                System.out.println("User with same User ID already exists!");
                return;
            }
        }
        users.add(user);
        System.out.println("User added successfully!");
    }

    public void removeUser(User user){
        if(users.contains(user)){
            users.remove(user);
        }
    }


    public List<User> getUsers(){
        return users;
    }
}
